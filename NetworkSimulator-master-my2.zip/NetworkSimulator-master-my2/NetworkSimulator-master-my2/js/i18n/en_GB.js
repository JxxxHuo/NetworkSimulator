var en_GB ={
    name: "English (GB)",
    locale: "en_GB"

    // Default language
}; 

uitranslation.registerLocale(en_GB);