
Add new inspect options "MAC table" and "ARP table". 

This lets students see the changes in switch MAC table and ARP table after packets are sent.

Jxxx Huo

----------------------------------------------------------------

# NetworkSimulator
Educational Network Simulator Project

Check out the project's webpage at: http://projects.bardok.net/educational-network-simulator/

(c) 2015 Jorge García Ochoa de Aspuru

bardok@gmail.com

@bardok

This project is covered by GPLv3 license.
