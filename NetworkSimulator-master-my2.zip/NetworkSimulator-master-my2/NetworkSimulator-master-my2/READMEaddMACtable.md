Add new inspect options "MAC table" and "ARP table".

This lets students understand better about switch MAC table and router ARP protocol.

# NetworkSimulator
Educational Network Simulator Project

Check out the project's webpage at: http://projects.bardok.net/educational-network-simulator/

(c) 2015 Jorge García Ochoa de Aspuru

bardok@gmail.com

@bardok

This project is covered by GPLv3 license.

